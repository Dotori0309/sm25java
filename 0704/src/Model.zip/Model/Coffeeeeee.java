package Model;

import java.io.*;
import java.util.*;

public class Coffeeeeee extends Drink {

    public double caffeineAmount;
    public String beanOrigin;
    public String roastLevel;

    public Coffeeeeee() {
    }

    public Coffeeeeee(double caffeineAmount, String beanOrigin, String roastLevel) {
        this.caffeineAmount = caffeineAmount;
        this.beanOrigin = beanOrigin;
        this.roastLevel = roastLevel;
    }

    public void drink() {
    }

    public void checkRoastLevel() {
    }

    @Override
    public void showInfo() {
    }
}
