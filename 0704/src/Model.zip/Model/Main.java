package Model;

public class Main {
    public static void main(String[] args) {
        AlcoholicDrink al = new AlcoholicDrink("dd", "ss", "ff", 1, 2, 3, 1.0, "kk");
        al.checkAlcoholLevel();
    }
}
